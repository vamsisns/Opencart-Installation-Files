<?php
// Text
$_['text_footer']  = '<a target="_blank" href="https://www.sitesnstores.com.au/">Sites n Stores</a> &copy; ' . date('Y') . ' All Rights Reserved.';